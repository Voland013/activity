#!/usr/bin/python3.9

print('Content-type:text/html\r\n\r')
print('<html>\n  <head>\n    <title>\nActivity Entry Form\n     </title>')
print('   </head>\n  <body>')

import psycopg2


errorRaised = False
try: # TODO: load auth data from file
  connection = psycopg2.connect(user="********", dbname="********",
  				password="*******")
except Exception as Exception_Raised:
  errorRaised = True
  print('    <p>\nNot Connected.\n     </p>')
  
from os import environ

if 'QUERY_STRING' in environ and environ['QUERY_STRING'] != '':
  print('    <p>')
  #print('Passed ', environ['QUERY_STRING'])
  #print('      <br>')
  parts = environ['QUERY_STRING'].split('&')
  partsNo = len(parts)
  #print(partsNo, ' parts')
  partCount = 0
  #print('      <ol>')
  partDict = {}
  while partCount < partsNo:
    #print('        <li>\n',parts[partCount])
    cleavage = parts[partCount].split('=')
    partDict[cleavage[0]] = cleavage[1]
    partCount += 1
  #print('       </ol>')
  print('Built dictionary ', partDict)
  print('     </p>')
  if 'endprevious' in partDict:  # TODO: add validity check
    kursor = connection.cursor()
    updateString = 'update activity set finish = now() where entryNo = (' + \
                   'select max(entryNo) from activity)'
    kursor.execute(updateString)
    connection.commit()
  # TODO: check for SQL injection  
  if 'activity' in partDict and partDict['activity'] != '':
    activity = partDict['activity']
    # convert codes to characters
    plusFound = activity.index('+')
    while plusFound != -1:
      
    insertion = 'insert into activity values(default,"' + \
                activity + '",'
    # TODO: add validity check
    if 'start' in partDict and partDict['start'] != '':
      startTime = '"' + partDict['start'] + '"'  # TODO: add validity check
    else:
      startTime = 'now()'
    insertion += startTime + ','
    if 'finish' in partDict and partDict['finish'] != '':
      hoursElapsed = minutesElapsed = finishTime = 0
      finish = ''
      if 'elapsed' in partDict and 'start' in partDict and \
         partDict['start'] != '':  # TODO: add validity check
        startParts = partDict['start'].split(':')
        startHour = int(startParts[0])
        startMinute = int(startParts[1])
        if ':' in partDict['finish']:
          elapsedParts = partDict['finish'].split(':')
          hoursElapsed = int(elapsedParts[0])
          minutesElapsed = int(elapsedParts[1])
        else:
          minutesElapsed = int(partDict['finish'])
          
        from time import mktime
	
        timeOfStart = mktime((0,1,1,startHour,startMinute,0,0,1,0,None,None))
        elapsedTime = mktime((0,1,1,hoursElapsed,minutesElapsed,0,0,1,0,None,
	                      None))
        finishTime = timeOfStart + elapsedTime
        finished = localtime(finishTime)
        finish = str(finished)
        # add finish to start, then add to insertion string
      else:  # TODO: add sanity check, finish after start
        finish = partDict['finish']
    else:
      insertion += 'default'
    insertion += ')'
    print('insertion prepared: ', insertion)
    

print('    <form>')

print('      <label for="activity">')
print('Activity:')
print('       </label>')
print('      <input type="text" id="activity" name="activity">')
print('      <br>')

print('      <label for="endprevious">')
print('End previous?')
print('       </label>')
print('      <input type="checkbox" name="endprevious">')
print('      <br>')

from time import strftime

startTimeDefault = strftime('%H:%M')
print('      <label for="start">')
print('Start:')
print('       </label>')
print('      <input type="text" id="start" name="start" value="' +
      startTimeDefault + '" size="3">')
print('      <br>')

print('      <label for="end">')
print('End:')
print('       </label>')
print('      <input type="text" id="end" name="end" size="3">')
print('      <label for="elapsed">')
print('Elapsed?')
print('      <input type="checkbox" name="elapsed">')
print('      <br>')

print('      <input type="submit" id="submit"')
print('       name="submit" value="Enter">')
print('     </form>')
print('   </body>\n </html>')
